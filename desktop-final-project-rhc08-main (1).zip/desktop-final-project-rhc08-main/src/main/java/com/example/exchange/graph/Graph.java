package com.example.exchange.graph;

import com.example.exchange.api.ExchangeService;
import com.example.exchange.api.model.HistoryResponse;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class Graph implements Initializable {

    public LineChart<String, Number> lineChart;
    public CategoryAxis xAxis;
    public NumberAxis yAxis;
    public ComboBox<Integer> hoursComboBox;
    public ComboBox<String> bucketComboBox;
    public Label statusLabel;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        hoursComboBox.getItems().addAll(24, 48, 72, 168);
        hoursComboBox.setValue(72);

        bucketComboBox.getItems().addAll("hour", "day");
        bucketComboBox.setValue("hour");

        loadGraph(null);
    }

    public void loadGraph(ActionEvent actionEvent) {
        int hours = hoursComboBox.getValue() != null ? hoursComboBox.getValue() : 72;
        String bucket = bucketComboBox.getValue() != null ? bucketComboBox.getValue() : "hour";

        statusLabel.setText("Loading...");
        lineChart.getData().clear();

        ExchangeService.createExchangeApi()
                .getHistory(hours, bucket)
                .enqueue(new Callback<HistoryResponse>() {
                    @Override
                    public void onResponse(Call<HistoryResponse> call,
                                           Response<HistoryResponse> response) {
                        if (!response.isSuccessful() || response.body() == null) {
                            Platform.runLater(() ->
                                    statusLabel.setText("Failed to load graph. Error: "
                                            + response.code()));
                            return;
                        }

                        HistoryResponse data = response.body();
                        List<HistoryResponse.BucketPoint> series = data.series;

                        if (series == null || series.isEmpty()) {
                            Platform.runLater(() -> {
                                statusLabel.setText(
                                        "No data available for selected range.");
                                lineChart.getData().clear();
                            });
                            return;
                        }

                        XYChart.Series<String, Number> chartSeries =
                                new XYChart.Series<>();
                        chartSeries.setName("Exchange Rate (LBP per USD)");

                        for (HistoryResponse.BucketPoint point : series) {
                            if (point.rate != null) {
                                chartSeries.getData().add(
                                        new XYChart.Data<>(point.bucket, point.rate));
                            }
                        }

                        Platform.runLater(() -> {
                            lineChart.getData().clear();
                            lineChart.getData().add(chartSeries);
                            statusLabel.setText("Showing " + series.size()
                                    + " data points.");
                        });
                    }

                    @Override
                    public void onFailure(Call<HistoryResponse> call,
                                          Throwable throwable) {
                        Platform.runLater(() ->
                                statusLabel.setText("Network error: "
                                        + throwable.getMessage()));
                    }
                });
    }
}