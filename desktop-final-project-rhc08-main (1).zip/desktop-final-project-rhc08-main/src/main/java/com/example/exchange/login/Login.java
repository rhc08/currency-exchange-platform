package com.example.exchange.login;

import com.example.exchange.Authentication;
import com.example.exchange.OnPageCompleteListener;
import com.example.exchange.PageCompleter;
import com.example.exchange.api.ExchangeService;
import com.example.exchange.api.model.Token;
import com.example.exchange.api.model.User;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Login implements PageCompleter {

    public TextField usernameTextField;
    public TextField passwordTextField;

    private OnPageCompleteListener onPageCompleteListener;

    @Override
    public void setOnPageCompleteListener(OnPageCompleteListener onPageCompleteListener) {
        this.onPageCompleteListener = onPageCompleteListener;
    }

    public void login(ActionEvent actionEvent) {
        String username = usernameTextField.getText().trim();
        String password = passwordTextField.getText().trim();

        if (username.isEmpty() || password.isEmpty()) {
            showError("Please enter username and password.");
            return;
        }

        User user = new User(username, password);

        ExchangeService.createExchangeApi()
                .authenticate(user)
                .enqueue(new Callback<Token>() {
                    @Override
                    public void onResponse(Call<Token> call, Response<Token> response) {
                        Platform.runLater(() -> {
                            switch (response.code()) {
                                case 200:
                                    if (response.body() != null) {
                                        // Save token
                                        Authentication.getInstance().saveToken(response.body().getToken());
                                        // Save username and role
                                        Authentication.getInstance().saveUserInfo(
                                                response.body().getUserName(),
                                                response.body().getRole()
                                        );
                                        // Navigate to main app
                                        if (onPageCompleteListener != null) {
                                            onPageCompleteListener.onPageCompleted();
                                        }
                                    }
                                    break;
                                case 401:
                                    showError("Invalid username or password.");
                                    break;
                                case 403:
                                    showError("Access forbidden. Your account may be disabled.");
                                    break;
                                case 429:
                                    showError("Too many login attempts. Please wait and try again.");
                                    break;
                                default:
                                    showError("Login failed. Server error: " + response.code());
                            }
                        });
                    }

                    @Override
                    public void onFailure(Call<Token> call, Throwable throwable) {
                        Platform.runLater(() -> showError("Network error. Please check your connection."));
                    }
                });
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Login Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
