package com.example.exchange;

import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class Parent implements Initializable, OnPageCompleteListener {

    public BorderPane borderPane;
    public Button dashboardButton;
    public Button transactionButton;
    public Button loginButton;
    public Button registerButton;
    public Button logoutButton;
    public Button graphButton;
    public Button notificationsButton;

    // Label to show logged-in username in the sidebar
    public Label usernameLabel;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        swapContent(Section.RATES);
    }

    @Override
    public void onPageCompleted() {
        swapContent(Section.RATES);
    }

    public void ratesSelected() {
        swapContent(Section.RATES);
    }

    public void graphSelected() {
        swapContent(Section.GRAPH);
    }

    public void transactionsSelected() {
        swapContent(Section.TRANSACTIONS);
    }

    public void notificationsSelected() {
        swapContent(Section.NOTIFICATIONS);
    }

    public void loginSelected() {
        swapContent(Section.LOGIN);
    }

    public void registerSelected() {
        swapContent(Section.REGISTER);
    }

    public void logoutSelected() {
        Authentication.getInstance().deleteToken();
        swapContent(Section.RATES);
    }

    private void setActiveButton(Section section) {
        Button[] navButtons = {
                dashboardButton,
                graphButton,
                transactionButton,
                notificationsButton,
                loginButton,
                registerButton,
                logoutButton
        };

        for (Button b : navButtons) {
            if (b != null) {
                b.getStyleClass().setAll("nav-button");
            }
        }

        Button active = switch (section) {
            case RATES -> dashboardButton;
            case GRAPH -> graphButton;
            case TRANSACTIONS -> transactionButton;
            case NOTIFICATIONS -> notificationsButton;
            case LOGIN -> loginButton;
            case REGISTER -> registerButton;
        };

        if (active != null) {
            active.getStyleClass().setAll("nav-button-active");
        }
    }

    private void updateNavigation() {
        boolean authenticated = Authentication.getInstance().getToken() != null;

        transactionButton.setVisible(authenticated);
        transactionButton.setManaged(authenticated);

        notificationsButton.setVisible(authenticated);
        notificationsButton.setManaged(authenticated);

        graphButton.setVisible(true);
        graphButton.setManaged(true);

        loginButton.setVisible(!authenticated);
        loginButton.setManaged(!authenticated);

        registerButton.setVisible(!authenticated);
        registerButton.setManaged(!authenticated);

        logoutButton.setVisible(authenticated);
        logoutButton.setManaged(authenticated);

        // Show logged-in username in sidebar
        if (usernameLabel != null) {
            if (authenticated) {
                String username = Authentication.getInstance().getUsername();
                String role = Authentication.getInstance().getRole();
                usernameLabel.setText((username != null ? username : "User")
                        + (role != null ? " (" + role + ")" : ""));
                usernameLabel.setVisible(true);
                usernameLabel.setManaged(true);
            } else {
                usernameLabel.setText("");
                usernameLabel.setVisible(false);
                usernameLabel.setManaged(false);
            }
        }
    }

    private void updateProofPanel(Section section) {
        ProofPanel proofPanel = new ProofPanel(section.getDisplayName());
        BorderPane.setAlignment(proofPanel, Pos.TOP_RIGHT);
        BorderPane.setMargin(proofPanel, new Insets(5, 5, 0, 0));
        borderPane.setTop(proofPanel);
    }

    private void swapContent(Section section) {
        try {
            URL url = getClass().getResource(section.getResource());
            FXMLLoader loader = new FXMLLoader(url);
            Node content = loader.load();

            ScrollPane scrollPane = new ScrollPane(content);
            scrollPane.setFitToWidth(true);
            scrollPane.setFitToHeight(false);
            scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
            scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
            scrollPane.setStyle("-fx-background-color: transparent; -fx-background: transparent;");

            borderPane.setCenter(scrollPane);

            if (section.doesComplete()) {
                ((PageCompleter) loader.getController()).setOnPageCompleteListener(this);
            }

            updateNavigation();
            updateProofPanel(section);
            setActiveButton(section);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private enum Section {
        RATES, GRAPH, TRANSACTIONS, NOTIFICATIONS, LOGIN, REGISTER;

        public String getResource() {
            return switch (this) {
                case RATES -> "/com/example/exchange/rates/rates.fxml";
                case GRAPH -> "/com/example/exchange/graph/graph.fxml";
                case TRANSACTIONS -> "/com/example/exchange/transactions/transactions.fxml";
                case NOTIFICATIONS -> "/com/example/exchange/notifications/notifications.fxml";
                case LOGIN -> "/com/example/exchange/login/login.fxml";
                case REGISTER -> "/com/example/exchange/register/register.fxml";
            };
        }

        public boolean doesComplete() {
            return switch (this) {
                case LOGIN, REGISTER -> true;
                default -> false;
            };
        }

        public String getDisplayName() {
            return switch (this) {
                case RATES -> "Dashboard";
                case GRAPH -> "Graph";
                case TRANSACTIONS -> "Transactions";
                case NOTIFICATIONS -> "Notifications";
                case LOGIN -> "Login";
                case REGISTER -> "Register";
            };
        }
    }
}
