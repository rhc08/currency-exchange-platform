package com.example.exchange.api.model;

import com.google.gson.annotations.SerializedName;

public class Token {
    @SerializedName("token")
    String token;

    @SerializedName("user_name")
    String userName;

    @SerializedName("role")
    String role;

    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }

    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
}