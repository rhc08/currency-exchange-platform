package com.example.exchange;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.util.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ProofPanel extends VBox {
    private final Label timeLabel;

    public ProofPanel(String screenName) {
        this.setStyle(
                "-fx-background-color: #ffffff;" +
                        "-fx-border-color: #e5e7eb;" +
                        "-fx-border-width: 1;" +
                        "-fx-padding: 7 12 7 12;" +
                        "-fx-background-radius: 6;" +
                        "-fx-border-radius: 6;"
        );
        this.setSpacing(2);
        this.setPadding(new Insets(7, 12, 7, 12));

        Label nameLabel   = new Label("Student: Rayane Chams Bacha");
        timeLabel         = new Label("Time: " + getCurrentTime());
        Label screenLabel = new Label("Screen: " + screenName);

        String boldStyle  = "-fx-font-size: 11px; -fx-text-fill: #0f1117; -fx-font-weight: bold;";
        String mutedStyle = "-fx-font-size: 11px; -fx-text-fill: #374151;";

        nameLabel.setStyle(boldStyle);
        timeLabel.setStyle(mutedStyle);
        screenLabel.setStyle(mutedStyle);

        this.getChildren().addAll(nameLabel, timeLabel, screenLabel);

        Timeline clock = new Timeline(new KeyFrame(Duration.seconds(1), e ->
                timeLabel.setText("Time: " + getCurrentTime())));
        clock.setCycleCount(Timeline.INDEFINITE);
        clock.play();
    }

    private String getCurrentTime() {
        return LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }
}