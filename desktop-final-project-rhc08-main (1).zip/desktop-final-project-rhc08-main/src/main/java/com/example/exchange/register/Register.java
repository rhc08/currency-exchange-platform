package com.example.exchange.register;

import com.example.exchange.Authentication;
import com.example.exchange.OnPageCompleteListener;
import com.example.exchange.PageCompleter;
import com.example.exchange.api.ExchangeService;
import com.example.exchange.api.model.Token;
import com.example.exchange.api.model.User;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Register implements PageCompleter {

    public TextField usernameTextField;
    public PasswordField passwordTextField;

    private OnPageCompleteListener onPageCompleteListener;

    @Override
    public void setOnPageCompleteListener(OnPageCompleteListener onPageCompleteListener) {
        this.onPageCompleteListener = onPageCompleteListener;
    }

    public void register(ActionEvent actionEvent) {
        String username = usernameTextField.getText().trim();
        String password = passwordTextField.getText().trim();

        if (username.isEmpty() || password.isEmpty()) {
            showError("Please enter username and password.");
            return;
        }

        User user = new User(username, password);

        ExchangeService.createExchangeApi()
                .addUser(user)
                .enqueue(new Callback<User>() {
                    @Override
                    public void onResponse(Call<User> call, Response<User> response) {
                        Platform.runLater(() -> {
                            switch (response.code()) {
                                case 200:
                                case 201:
                                    authenticateAfterRegister(user);
                                    break;
                                case 400:
                                    showError("Invalid registration details. Please check your input.");
                                    break;
                                case 403:
                                    showError("Registration not allowed.");
                                    break;
                                case 409:
                                    showError("Username already exists. Please choose another.");
                                    break;
                                case 429:
                                    showError("Too many attempts. Please wait and try again.");
                                    break;
                                default:
                                    showError("Registration failed. Server error: " + response.code());
                            }
                        });
                    }

                    @Override
                    public void onFailure(Call<User> call, Throwable throwable) {
                        Platform.runLater(() -> showError("Network error. Please check your connection."));
                    }
                });
    }

    private void authenticateAfterRegister(User user) {
        ExchangeService.createExchangeApi()
                .authenticate(user)
                .enqueue(new Callback<Token>() {
                    @Override
                    public void onResponse(Call<Token> call, Response<Token> response) {
                        Platform.runLater(() -> {
                            switch (response.code()) {
                                case 200:
                                    if (response.body() != null) {
                                        // Save token
                                        Authentication.getInstance().saveToken(response.body().getToken());
                                        // Save username and role
                                        Authentication.getInstance().saveUserInfo(
                                                response.body().getUserName(),
                                                response.body().getRole()
                                        );
                                        // Show success message
                                        Alert success = new Alert(Alert.AlertType.INFORMATION);
                                        success.setTitle("Registration Successful");
                                        success.setHeaderText(null);
                                        success.setContentText("Account created successfully! Welcome, "
                                                + response.body().getUserName() + "!");
                                        success.showAndWait();
                                        // Navigate to main app
                                        if (onPageCompleteListener != null) {
                                            onPageCompleteListener.onPageCompleted();
                                        }
                                    }
                                    break;
                                case 401:
                                    showError("Registration succeeded but login failed. Please login manually.");
                                    break;
                                case 429:
                                    showError("Too many attempts. Please wait and try again.");
                                    break;
                                default:
                                    showError("Auto-login failed. Server error: " + response.code());
                            }
                        });
                    }

                    @Override
                    public void onFailure(Call<Token> call, Throwable throwable) {
                        Platform.runLater(() -> showError("Network error during auto-login. Please login manually."));
                    }
                });
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Registration Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
