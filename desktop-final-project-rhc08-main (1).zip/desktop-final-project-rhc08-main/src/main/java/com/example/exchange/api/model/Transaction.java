package com.example.exchange.api.model;

import com.google.gson.annotations.SerializedName;

public class Transaction {

    @SerializedName("id")
    public Integer id;

    @SerializedName("usd_amount")
    public Float usdAmount;

    @SerializedName("lbp_amount")
    public Float lbpAmount;

    @SerializedName("usd_to_lbp")
    public Boolean usdToLbp;

    @SerializedName("added_date")
    public String addedDate;

    public Transaction(float usdAmount, float lbpAmount, boolean usdToLbp) {
        this.usdAmount = usdAmount;
        this.lbpAmount = lbpAmount;
        this.usdToLbp = usdToLbp;
    }

    public Integer getId() {
        return id;
    }

    public Float getUsdAmount() {
        return usdAmount;
    }

    public Float getLbpAmount() {
        return lbpAmount;
    }

    public Boolean getUsdToLbp() {
        return usdToLbp;
    }

    public String getAddedDate() {
        return addedDate;
    }
}