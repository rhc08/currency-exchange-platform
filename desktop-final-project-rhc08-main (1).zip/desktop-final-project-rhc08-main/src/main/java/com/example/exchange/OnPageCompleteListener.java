package com.example.exchange;

public interface OnPageCompleteListener {
    void onPageCompleted();
}