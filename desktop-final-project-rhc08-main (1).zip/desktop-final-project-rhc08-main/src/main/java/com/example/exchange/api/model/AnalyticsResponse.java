package com.example.exchange.api.model;

import com.google.gson.annotations.SerializedName;

public class AnalyticsResponse {

    @SerializedName("count")
    public Integer count;

    @SerializedName("min")
    public Double min;

    @SerializedName("max")
    public Double max;

    @SerializedName("avg")
    public Double avg;

    @SerializedName("first_rate")
    public Double firstRate;

    @SerializedName("last_rate")
    public Double lastRate;

    @SerializedName("pct_change")
    public Double pctChange;

    @SerializedName("trend")
    public String trend;
}