package com.example.exchange.api;

import com.example.exchange.api.model.AnalyticsResponse;
import com.example.exchange.api.model.ExchangeRates;
import com.example.exchange.api.model.HistoryResponse;
import com.example.exchange.api.model.Notification;
import com.example.exchange.api.model.Token;
import com.example.exchange.api.model.Transaction;
import com.example.exchange.api.model.User;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.PATCH;
import retrofit2.http.POST;
import retrofit2.http.Query;

import java.util.List;
import com.example.exchange.api.model.Notification;
import okhttp3.ResponseBody;
import retrofit2.http.DELETE;
import retrofit2.http.PATCH;

public interface Exchange {

    @POST("/user")
    Call<User> addUser(@Body User user);

    @POST("/authentication")
    Call<Token> authenticate(@Body User user);

    @GET("/exchangeRate")
    Call<ExchangeRates> getExchangeRates();

    @GET("/exchangeRate/analytics")
    Call<AnalyticsResponse> getAnalytics(@Query("hours") int hours);

    @GET("/exchangeRate/history")
    Call<HistoryResponse> getHistory(@Query("hours") int hours,
                                     @Query("bucket") String bucket);

    @POST("/transaction")
    Call<Object> addTransaction(@Body Transaction transaction,
                                @Header("Authorization") String authorization);

    @GET("/transaction")
    Call<List<Transaction>> getTransactions(@Header("Authorization") String authorization);

    @GET("/transaction/export")
    Call<ResponseBody> exportTransactionsCSV(@Header("Authorization") String authorization);

    @GET("/notifications")
    Call<List<Notification>> getNotifications(@Header("Authorization") String authorization);

    @PATCH("/notifications/{id}/read")
    Call<Notification> markNotificationRead(@retrofit2.http.Path("id") int id,
                                            @Header("Authorization") String authorization);

    @DELETE("/notifications/{id}")
    Call<ResponseBody> deleteNotification(@retrofit2.http.Path("id") int id,
                                          @Header("Authorization") String authorization);


}