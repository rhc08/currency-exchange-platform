package com.example.exchange.api.model;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class HistoryResponse {

    @SerializedName("bucket")
    public String bucket;

    @SerializedName("hours")
    public Integer hours;

    @SerializedName("start_date")
    public String startDate;

    @SerializedName("end_date")
    public String endDate;

    @SerializedName("series")
    public List<BucketPoint> series;

    public static class BucketPoint {
        @SerializedName("bucket")
        public String bucket;

        @SerializedName("rate")
        public Double rate;

        @SerializedName("count")
        public Integer count;
    }
}