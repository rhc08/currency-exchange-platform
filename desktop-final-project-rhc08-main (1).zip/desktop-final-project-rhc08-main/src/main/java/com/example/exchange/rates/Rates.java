package com.example.exchange.rates;

import com.example.exchange.Authentication;
import com.example.exchange.api.Exchange;
import com.example.exchange.api.ExchangeService;
import com.example.exchange.api.model.AnalyticsResponse;
import com.example.exchange.api.model.ExchangeRates;
import com.example.exchange.api.model.Transaction;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import java.text.DecimalFormat;

public class Rates {

    public Label buyUsdRateLabel;
    public Label sellUsdRateLabel;
    public TextField lbpTextField;
    public TextField usdTextField;
    public ToggleGroup transactionType;

    public Label minRateLabel;
    public Label maxRateLabel;
    public Label avgRateLabel;
    public Label pctChangeLabel;
    public Label trendLabel;
    public Label volatilityLabel;
    public Label spikeLabel;
    public Label countLabel;
    public ComboBox<Integer> hoursComboBox;

    private final Exchange api = ExchangeService.createExchangeApi();
    private final DecimalFormat rateFormat = new DecimalFormat("#,##0.00");

    private double usdToLbpRateValue = 0.0;
    private double lbpToUsdRateValue = 0.0;
    private boolean updatingFields = false;

    public void initialize() {
        hoursComboBox.getItems().addAll(24, 48, 72, 168);
        hoursComboBox.setValue(72);

        fetchRates();
        fetchAnalytics(null);
        restrictClipboard(usdTextField);
        restrictClipboard(lbpTextField);
        setupCalculator();
    }

    public void fetchAnalytics(ActionEvent actionEvent) {
        int hours = hoursComboBox.getValue() != null ? hoursComboBox.getValue() : 72;

        api.getAnalytics(hours).enqueue(new Callback<AnalyticsResponse>() {
            @Override
            public void onResponse(Call<AnalyticsResponse> call, Response<AnalyticsResponse> response) {
                if (!response.isSuccessful() || response.body() == null) {
                    Platform.runLater(() -> clearAnalytics());
                    return;
                }

                AnalyticsResponse data = response.body();

                Platform.runLater(() -> {
                    if (data.count == null || data.count == 0) {
                        clearAnalytics();
                        return;
                    }

                    // Basic stats
                    minRateLabel.setText(data.min != null ? rateFormat.format(data.min) : "--");
                    maxRateLabel.setText(data.max != null ? rateFormat.format(data.max) : "--");
                    avgRateLabel.setText(data.avg != null ? rateFormat.format(data.avg) : "--");

                    // % Change
                    if (data.pctChange != null) {
                        String sign = data.pctChange >= 0 ? "+" : "";
                        pctChangeLabel.setText(sign + String.format("%.2f", data.pctChange) + "%");
                        pctChangeLabel.setStyle(data.pctChange >= 0
                                ? "-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #16a34a;"
                                : "-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #dc2626;");
                    } else {
                        pctChangeLabel.setText("--");
                        pctChangeLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #0f1117;");
                    }

                    // Trend
                    String trendText = switch (data.trend != null ? data.trend : "") {
                        case "up" -> "The rate is increasing";
                        case "down" -> "The rate is decreasing";
                        case "flat" -> "The rate is stable";
                        default -> "N/A";
                    };
                    trendLabel.setText(trendText);

                    // Volatility — computed from max-min spread vs avg
                    if (data.max != null && data.min != null && data.avg != null && data.avg != 0) {
                        double spread = data.max - data.min;
                        double volatilityPct = (spread / data.avg) * 100;
                        if (volatilityPct < 1.0) {
                            volatilityLabel.setText("Low fluctuations");
                        } else if (volatilityPct < 3.0) {
                            volatilityLabel.setText("Moderate fluctuations");
                        } else {
                            volatilityLabel.setText("High fluctuations");
                        }
                    } else {
                        volatilityLabel.setText("N/A");
                    }

                    // Biggest spike — difference between max and first rate
                    if (data.max != null && data.firstRate != null) {
                        double spike = data.max - data.firstRate;
                        String spikeSign = spike >= 0 ? "+" : "";
                        spikeLabel.setText(spikeSign + rateFormat.format(spike) + " LBP");
                    } else {
                        spikeLabel.setText("N/A");
                    }

                    // Transaction count
                    countLabel.setText(String.valueOf(data.count));
                });
            }

            @Override
            public void onFailure(Call<AnalyticsResponse> call, Throwable throwable) {
                Platform.runLater(() -> {
                    trendLabel.setText("Network error");
                    volatilityLabel.setText("--");
                    spikeLabel.setText("--");
                    countLabel.setText("--");
                });
            }
        });
    }

    private void clearAnalytics() {
        minRateLabel.setText("--");
        maxRateLabel.setText("--");
        avgRateLabel.setText("--");
        pctChangeLabel.setText("--");
        trendLabel.setText("No data");
        volatilityLabel.setText("No data");
        spikeLabel.setText("No data");
        countLabel.setText("0");
    }

    private void restrictClipboard(TextField textField) {
        textField.addEventFilter(KeyEvent.KEY_PRESSED, event -> {
            if (event.isShortcutDown() &&
                    (event.getCode() == KeyCode.C ||
                            event.getCode() == KeyCode.V ||
                            event.getCode() == KeyCode.X)) {
                event.consume();
            }
        });
    }

    private void setupCalculator() {
        usdTextField.textProperty().addListener((obs, oldValue, newValue) -> {
            if (updatingFields) return;
            if (newValue == null || newValue.isBlank()) {
                updatingFields = true;
                lbpTextField.clear();
                updatingFields = false;
                return;
            }
            try {
                double usd = Double.parseDouble(newValue.replace(",", ""));
                RadioButton selected = (RadioButton) transactionType.getSelectedToggle();
                if (selected == null) return;
                double rate = selected.getText().equalsIgnoreCase("USD → LBP")
                        ? usdToLbpRateValue : lbpToUsdRateValue;
                if (rate == 0) {
                    updatingFields = true;
                    lbpTextField.clear();
                    updatingFields = false;
                    return;
                }
                updatingFields = true;
                lbpTextField.setText(rateFormat.format(usd * rate));
                updatingFields = false;
            } catch (NumberFormatException ignored) {}
        });

        lbpTextField.textProperty().addListener((obs, oldValue, newValue) -> {
            if (updatingFields) return;
            if (newValue == null || newValue.isBlank()) {
                updatingFields = true;
                usdTextField.clear();
                updatingFields = false;
                return;
            }
            try {
                double lbp = Double.parseDouble(newValue.replace(",", ""));
                RadioButton selected = (RadioButton) transactionType.getSelectedToggle();
                if (selected == null) return;
                double rate = selected.getText().equalsIgnoreCase("USD → LBP")
                        ? usdToLbpRateValue : lbpToUsdRateValue;
                if (rate == 0) return;
                updatingFields = true;
                usdTextField.setText(rateFormat.format(lbp / rate));
                updatingFields = false;
            } catch (NumberFormatException ignored) {}
        });

        transactionType.selectedToggleProperty().addListener((obs, oldToggle, newToggle) -> {
            if (newToggle == null) return;
            if (usdTextField.getText() != null && !usdTextField.getText().isBlank()) {
                try {
                    double usd = Double.parseDouble(usdTextField.getText().replace(",", ""));
                    RadioButton selected = (RadioButton) newToggle;
                    double rate = selected.getText().equalsIgnoreCase("USD → LBP")
                            ? usdToLbpRateValue : lbpToUsdRateValue;
                    if (rate == 0) {
                        updatingFields = true;
                        lbpTextField.clear();
                        updatingFields = false;
                        return;
                    }
                    updatingFields = true;
                    lbpTextField.setText(rateFormat.format(usd * rate));
                    updatingFields = false;
                } catch (NumberFormatException ignored) {}
            }
        });
    }

    private void fetchRates() {
        api.getExchangeRates().enqueue(new Callback<ExchangeRates>() {
            @Override
            public void onResponse(Call<ExchangeRates> call, Response<ExchangeRates> response) {
                if (!response.isSuccessful() || response.body() == null) return;

                ExchangeRates rates = response.body();
                usdToLbpRateValue = rates.usdToLbp > 0 ? rates.usdToLbp : 0;
                lbpToUsdRateValue = rates.lbpToUsd > 0 ? (1.0 / rates.lbpToUsd) : 0.0;

                Platform.runLater(() -> {
                    buyUsdRateLabel.setText(usdToLbpRateValue > 0 ? rateFormat.format(usdToLbpRateValue) : "--");
                    sellUsdRateLabel.setText(lbpToUsdRateValue > 0 ? rateFormat.format(lbpToUsdRateValue) : "--");
                });
            }

            @Override
            public void onFailure(Call<ExchangeRates> call, Throwable throwable) {
                System.err.println("Network error: " + throwable.getMessage());
            }
        });
    }

    public void addTransaction(ActionEvent actionEvent) {
        try {
            String usdInput = usdTextField.getText().trim();
            String lbpInput = lbpTextField.getText().trim();

            if (usdInput.isEmpty() || lbpInput.isEmpty()) {
                showError("Please enter both USD and LBP amounts.");
                return;
            }

            float usdAmount = Float.parseFloat(usdInput.replace(",", ""));
            float lbpAmount = Float.parseFloat(lbpInput.replace(",", ""));

            if (usdAmount <= 0 || lbpAmount <= 0) {
                showError("Amounts must be greater than zero.");
                return;
            }

            RadioButton selected = (RadioButton) transactionType.getSelectedToggle();
            if (selected == null) {
                showError("Please choose a direction.");
                return;
            }

            boolean usdToLbp = selected.getText().equalsIgnoreCase("USD → LBP");
            String userToken = Authentication.getInstance().getToken();
            String authHeader = userToken != null ? "Bearer " + userToken : null;

            Transaction transaction = new Transaction(usdAmount, lbpAmount, usdToLbp);

            api.addTransaction(transaction, authHeader).enqueue(new Callback<Object>() {
                @Override
                public void onResponse(Call<Object> call, Response<Object> response) {
                    Platform.runLater(() -> {
                        switch (response.code()) {
                            case 200:
                            case 201:
                                showSuccess("Transaction added successfully!");
                                usdTextField.clear();
                                lbpTextField.clear();
                                fetchRates();
                                fetchAnalytics(null);
                                break;
                            case 400:
                                showError("Invalid transaction. Check amounts.");
                                break;
                            case 401:
                                showError("Unauthorized. Please login first.");
                                break;
                            case 403:
                                showError("Forbidden. You cannot perform this action.");
                                break;
                            case 429:
                                showError("Too many requests. Please wait.");
                                break;
                            default:
                                showError("Transaction failed. Error: " + response.code());
                        }
                    });
                }

                @Override
                public void onFailure(Call<Object> call, Throwable throwable) {
                    Platform.runLater(() -> showError("Network error while adding transaction."));
                }
            });

        } catch (Exception e) {
            showError("Invalid input. Please enter valid numbers.");
        }
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showSuccess(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}