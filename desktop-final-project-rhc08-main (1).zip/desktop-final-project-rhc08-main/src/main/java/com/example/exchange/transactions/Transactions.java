package com.example.exchange.transactions;

import com.example.exchange.Authentication;
import com.example.exchange.api.ExchangeService;
import com.example.exchange.api.model.Transaction;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.FileChooser;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class Transactions implements Initializable {

    public TableColumn<Transaction, Float> lbpAmount;
    public TableColumn<Transaction, Float> usdAmount;
    public TableColumn<Transaction, String> transactionDate;
    public TableColumn<Transaction, Boolean> directionColumn;
    public TableView<Transaction> tableView;
    public Label statusLabel;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        usdAmount.setCellValueFactory(new PropertyValueFactory<>("usdAmount"));
        lbpAmount.setCellValueFactory(new PropertyValueFactory<>("lbpAmount"));
        transactionDate.setCellValueFactory(new PropertyValueFactory<>("addedDate"));

        directionColumn.setCellValueFactory(new PropertyValueFactory<>("usdToLbp"));
        directionColumn.setCellFactory(col -> new javafx.scene.control.TableCell<>() {
            @Override
            protected void updateItem(Boolean item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(item ? "USD → LBP" : "LBP → USD");
                }
            }
        });

        loadTransactions();
    }

    public void refresh(ActionEvent actionEvent) {
        loadTransactions();
    }

    private void loadTransactions() {
        String token = Authentication.getInstance().getToken();
        if (token == null) {
            statusLabel.setText("Please login to view transactions.");
            statusLabel.setStyle("-fx-text-fill: red;");
            return;
        }

        statusLabel.setText("Loading...");
        statusLabel.setStyle("-fx-text-fill: blue;");

        ExchangeService.createExchangeApi()
                .getTransactions("Bearer " + token)
                .enqueue(new Callback<List<Transaction>>() {
                    @Override
                    public void onResponse(Call<List<Transaction>> call,
                                           Response<List<Transaction>> response) {
                        Platform.runLater(() -> {
                            switch (response.code()) {
                                case 200:
                                    if (response.body() != null) {
                                        tableView.setItems(
                                                FXCollections.observableArrayList(response.body())
                                        );
                                        statusLabel.setText(
                                                response.body().size() + " transaction(s) found."
                                        );
                                        statusLabel.setStyle("-fx-text-fill: green;");
                                    } else {
                                        tableView.setItems(FXCollections.observableArrayList());
                                        statusLabel.setText("No transactions found.");
                                        statusLabel.setStyle("-fx-text-fill: orange;");
                                    }
                                    break;

                                case 401:
                                    statusLabel.setText("Unauthorized. Please login again.");
                                    statusLabel.setStyle("-fx-text-fill: red;");
                                    break;

                                case 403:
                                    statusLabel.setText("Forbidden.");
                                    statusLabel.setStyle("-fx-text-fill: red;");
                                    break;

                                case 429:
                                    statusLabel.setText("Too many requests. Please wait.");
                                    statusLabel.setStyle("-fx-text-fill: red;");
                                    break;

                                default:
                                    statusLabel.setText("Failed to load. Error: " + response.code());
                                    statusLabel.setStyle("-fx-text-fill: red;");
                            }
                        });
                    }

                    @Override
                    public void onFailure(Call<List<Transaction>> call,
                                          Throwable throwable) {
                        Platform.runLater(() -> {
                            statusLabel.setText("Network error.");
                            statusLabel.setStyle("-fx-text-fill: red;");
                        });
                    }
                });
    }

    public void exportCSV(ActionEvent actionEvent) {
        String token = Authentication.getInstance().getToken();
        if (token == null) {
            showError("Please login first.");
            return;
        }

        statusLabel.setText("Exporting...");
        statusLabel.setStyle("-fx-text-fill: blue;");

        ExchangeService.createExchangeApi()
                .exportTransactionsCSV("Bearer " + token)
                .enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call,
                                           Response<ResponseBody> response) {
                        Platform.runLater(() -> {
                            switch (response.code()) {
                                case 200:
                                    if (response.body() != null) {
                                        saveCSVFile(response.body());
                                    } else {
                                        statusLabel.setText("No data to export.");
                                        statusLabel.setStyle("-fx-text-fill: orange;");
                                    }
                                    break;

                                case 401:
                                    showError("Unauthorized. Please login again.");
                                    statusLabel.setText("Export failed: Unauthorized.");
                                    statusLabel.setStyle("-fx-text-fill: red;");
                                    break;

                                case 404:
                                    statusLabel.setText("No transactions to export.");
                                    statusLabel.setStyle("-fx-text-fill: orange;");
                                    break;

                                default:
                                    showError("Export failed. Error: " + response.code());
                                    statusLabel.setStyle("-fx-text-fill: red;");
                            }
                        });
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable throwable) {
                        Platform.runLater(() -> {
                            showError("Network error during export.");
                            statusLabel.setText("Export failed.");
                            statusLabel.setStyle("-fx-text-fill: red;");
                        });
                    }
                });
    }

    private void saveCSVFile(ResponseBody body) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save CSV File");
        fileChooser.setInitialFileName("transactions.csv");
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("CSV Files", "*.csv")
        );

        File file = fileChooser.showSaveDialog(tableView.getScene().getWindow());
        if (file == null) {
            statusLabel.setText("Export cancelled.");
            statusLabel.setStyle("-fx-text-fill: orange;");
            return;
        }

        try (InputStream is = body.byteStream();
             FileOutputStream fos = new FileOutputStream(file)) {
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = is.read(buffer)) != -1) {
                fos.write(buffer, 0, bytesRead);
            }
            statusLabel.setText("Exported successfully to: " + file.getName());
            statusLabel.setStyle("-fx-text-fill: green;");
        } catch (Exception e) {
            showError("Failed to save file: " + e.getMessage());
            statusLabel.setStyle("-fx-text-fill: red;");
        }
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}