package com.example.exchange.notifications;

import com.example.exchange.Authentication;
import com.example.exchange.api.ExchangeService;
import com.example.exchange.api.model.Notification;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.paint.Color;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Notifications implements Initializable {

    public TableView<Notification> tableView;
    public TableColumn<Notification, Integer> idColumn;
    public TableColumn<Notification, String> titleColumn;
    public TableColumn<Notification, String> typeColumn;
    public TableColumn<Notification, String> messageColumn;
    public TableColumn<Notification, String> createdAtColumn;
    public TableColumn<Notification, String> readStatusColumn;
    public Label statusLabel;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        typeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));
        messageColumn.setCellValueFactory(new PropertyValueFactory<>("message"));
        createdAtColumn.setCellValueFactory(new PropertyValueFactory<>("createdAt"));
        readStatusColumn.setCellValueFactory(new PropertyValueFactory<>("readStatus"));

        // Optional: make read/unread easier to notice
        readStatusColumn.setCellFactory(column -> new TableCell<>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setStyle("");
                } else {
                    setText(item);
                    if ("Read".equalsIgnoreCase(item)) {
                        setStyle("-fx-text-fill: #6b7280; -fx-font-weight: normal;");
                    } else {
                        setStyle("-fx-text-fill: #16a34a; -fx-font-weight: bold;");
                    }
                }
            }
        });

        loadNotifications();
    }

    public void refresh(ActionEvent actionEvent) {
        loadNotifications();
    }

    public void markAsRead(ActionEvent actionEvent) {
        Notification selected = tableView.getSelectionModel().getSelectedItem();

        if (selected == null) {
            showError("Please select a notification first.");
            return;
        }

        if (selected.isRead()) {
            statusLabel.setText("Selected notification is already marked as read.");
            statusLabel.setStyle("-fx-text-fill: orange;");
            return;
        }

        String token = Authentication.getInstance().getToken();
        if (token == null) {
            statusLabel.setText("Please login first.");
            statusLabel.setStyle("-fx-text-fill: red;");
            return;
        }

        statusLabel.setText("Marking as read...");
        statusLabel.setStyle("-fx-text-fill: blue;");

        ExchangeService.createExchangeApi()
                .markNotificationRead(selected.getId(), "Bearer " + token)
                .enqueue(new Callback<Notification>() {
                    @Override
                    public void onResponse(Call<Notification> call, Response<Notification> response) {
                        Platform.runLater(() -> {
                            switch (response.code()) {
                                case 200:
                                    // update selected row immediately
                                    selected.setRead(true);
                                    tableView.refresh();

                                    statusLabel.setText("Notification marked as read successfully.");
                                    statusLabel.setStyle("-fx-text-fill: green;");
                                    break;

                                case 401:
                                    statusLabel.setText("Unauthorized. Please login again.");
                                    statusLabel.setStyle("-fx-text-fill: red;");
                                    break;

                                case 404:
                                    statusLabel.setText("Notification not found.");
                                    statusLabel.setStyle("-fx-text-fill: red;");
                                    break;

                                default:
                                    statusLabel.setText("Failed to mark as read. Error: " + response.code());
                                    statusLabel.setStyle("-fx-text-fill: red;");
                            }
                        });
                    }

                    @Override
                    public void onFailure(Call<Notification> call, Throwable throwable) {
                        Platform.runLater(() -> {
                            statusLabel.setText("Network error while marking as read.");
                            statusLabel.setStyle("-fx-text-fill: red;");
                        });
                    }
                });
    }

    public void deleteNotification(ActionEvent actionEvent) {
        Notification selected = tableView.getSelectionModel().getSelectedItem();

        if (selected == null) {
            showError("Please select a notification first.");
            return;
        }

        String token = Authentication.getInstance().getToken();
        if (token == null) {
            statusLabel.setText("Please login first.");
            statusLabel.setStyle("-fx-text-fill: red;");
            return;
        }

        statusLabel.setText("Deleting...");
        statusLabel.setStyle("-fx-text-fill: blue;");

        ExchangeService.createExchangeApi()
                .deleteNotification(selected.getId(), "Bearer " + token)
                .enqueue(new Callback<okhttp3.ResponseBody>() {
                    @Override
                    public void onResponse(Call<okhttp3.ResponseBody> call, Response<okhttp3.ResponseBody> response) {
                        Platform.runLater(() -> {
                            switch (response.code()) {
                                case 200:
                                    tableView.getItems().remove(selected);
                                    statusLabel.setText("Notification deleted.");
                                    statusLabel.setStyle("-fx-text-fill: green;");
                                    break;

                                case 401:
                                    statusLabel.setText("Unauthorized. Please login again.");
                                    statusLabel.setStyle("-fx-text-fill: red;");
                                    break;

                                case 404:
                                    statusLabel.setText("Notification not found.");
                                    statusLabel.setStyle("-fx-text-fill: red;");
                                    break;

                                default:
                                    statusLabel.setText("Delete failed. Error: " + response.code());
                                    statusLabel.setStyle("-fx-text-fill: red;");
                            }
                        });
                    }

                    @Override
                    public void onFailure(Call<okhttp3.ResponseBody> call, Throwable throwable) {
                        Platform.runLater(() -> {
                            statusLabel.setText("Network error.");
                            statusLabel.setStyle("-fx-text-fill: red;");
                        });
                    }
                });
    }

    private void loadNotifications() {
        String token = Authentication.getInstance().getToken();
        if (token == null) {
            statusLabel.setText("Please login to view notifications.");
            statusLabel.setStyle("-fx-text-fill: red;");
            tableView.getItems().clear();
            return;
        }

        statusLabel.setText("Loading...");
        statusLabel.setStyle("-fx-text-fill: blue;");

        ExchangeService.createExchangeApi()
                .getNotifications("Bearer " + token)
                .enqueue(new Callback<List<Notification>>() {
                    @Override
                    public void onResponse(Call<List<Notification>> call, Response<List<Notification>> response) {
                        Platform.runLater(() -> {
                            switch (response.code()) {
                                case 200:
                                    if (response.body() != null) {
                                        tableView.getItems().setAll(response.body());
                                        statusLabel.setText(response.body().size() + " notification(s) found.");
                                        statusLabel.setStyle("-fx-text-fill: green;");
                                    } else {
                                        tableView.getItems().clear();
                                        statusLabel.setText("No notifications found.");
                                        statusLabel.setStyle("-fx-text-fill: orange;");
                                    }
                                    break;

                                case 401:
                                    tableView.getItems().clear();
                                    statusLabel.setText("Unauthorized. Please login again.");
                                    statusLabel.setStyle("-fx-text-fill: red;");
                                    break;

                                case 403:
                                    tableView.getItems().clear();
                                    statusLabel.setText("Forbidden.");
                                    statusLabel.setStyle("-fx-text-fill: red;");
                                    break;

                                case 429:
                                    tableView.getItems().clear();
                                    statusLabel.setText("Too many requests. Please wait.");
                                    statusLabel.setStyle("-fx-text-fill: red;");
                                    break;

                                default:
                                    tableView.getItems().clear();
                                    statusLabel.setText("Failed to load. Error: " + response.code());
                                    statusLabel.setStyle("-fx-text-fill: red;");
                            }
                        });
                    }

                    @Override
                    public void onFailure(Call<List<Notification>> call, Throwable throwable) {
                        Platform.runLater(() -> {
                            tableView.getItems().clear();
                            statusLabel.setText("Network error.");
                            statusLabel.setStyle("-fx-text-fill: red;");
                        });
                    }
                });
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}