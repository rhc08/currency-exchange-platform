package com.example.exchange;

import java.util.prefs.Preferences;

public class Authentication {
    private static Authentication instance;
    private static final String TOKEN_KEY = "TOKEN";
    private static final String USERNAME_KEY = "USERNAME";
    private static final String ROLE_KEY = "ROLE";

    private String token;
    private String username;
    private String role;
    private final Preferences pref;

    private Authentication() {
        pref = Preferences.userRoot().node(this.getClass().getName());
        token = pref.get(TOKEN_KEY, null);
        username = pref.get(USERNAME_KEY, null);
        role = pref.get(ROLE_KEY, null);
    }

    public static Authentication getInstance() {
        if (instance == null) {
            instance = new Authentication();
        }
        return instance;
    }

    public String getToken() { return token; }
    public String getUsername() { return username; }
    public String getRole() { return role; }

    public void saveToken(String token) {
        this.token = token;
        pref.put(TOKEN_KEY, token);
    }

    public void saveUserInfo(String username, String role) {
        this.username = username;
        this.role = role;
        pref.put(USERNAME_KEY, username);
        pref.put(ROLE_KEY, role);
    }

    public void deleteToken() {
        this.token = null;
        this.username = null;
        this.role = null;
        pref.remove(TOKEN_KEY);
        pref.remove(USERNAME_KEY);
        pref.remove(ROLE_KEY);
    }
}