module com.example.exchange {

    requires javafx.controls;
    requires javafx.fxml;

    requires retrofit2;
    requires retrofit2.converter.gson;
    requires com.google.gson;
    requires java.sql;
    requires java.prefs;
    requires okhttp3;

    opens com.example.exchange to javafx.fxml;
    opens com.example.exchange.rates to javafx.fxml;
    opens com.example.exchange.login to javafx.fxml;
    opens com.example.exchange.register to javafx.fxml;
    opens com.example.exchange.transactions to javafx.fxml;
    opens com.example.exchange.api to javafx.fxml;
    opens com.example.exchange.api.model to javafx.base, com.google.gson;
    opens com.example.exchange.graph to javafx.fxml;

    exports com.example.exchange;
    exports com.example.exchange.api;

    exports com.example.exchange.notifications;
    opens com.example.exchange.notifications to javafx.fxml;
}