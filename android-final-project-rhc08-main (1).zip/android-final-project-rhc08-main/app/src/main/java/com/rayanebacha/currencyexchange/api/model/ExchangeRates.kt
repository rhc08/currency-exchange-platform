package com.rayanebacha.currencyexchange.api.model

import com.google.gson.annotations.SerializedName

class ExchangeRates {
    @SerializedName("usd_to_lbp_rate")
    var usdToLbp: Float? = null

    @SerializedName("lbp_to_usd_rate")
    var lbpToUsd: Float? = null
}