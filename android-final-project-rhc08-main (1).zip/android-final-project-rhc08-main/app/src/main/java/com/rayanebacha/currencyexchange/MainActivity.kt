package com.rayanebacha.currencyexchange

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.google.android.material.textfield.TextInputLayout
import com.rayanebacha.currencyexchange.api.Authentication
import com.rayanebacha.currencyexchange.api.ExchangeService
import com.rayanebacha.currencyexchange.api.model.Transaction
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private var fab: FloatingActionButton? = null
    private var transactionDialog: View? = null
    private var menu: Menu? = null
    private var tabLayout: TabLayout? = null
    private var tabsViewPager: ViewPager2? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Authentication.initialize(this)

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.title = "Currency Exchange"

        ProofPanelHelper.start(window.decorView.rootView, "Exchange Dashboard")

        fab = findViewById(R.id.fab)
        tabLayout = findViewById(R.id.tabLayout)
        tabsViewPager = findViewById(R.id.tabsViewPager)

        tabLayout?.tabMode = TabLayout.MODE_FIXED
        tabLayout?.isInlineLabel = true
        tabsViewPager?.isUserInputEnabled = true

        val adapter = TabsPagerAdapter(supportFragmentManager, lifecycle)
        tabsViewPager?.adapter = adapter

        TabLayoutMediator(tabLayout!!, tabsViewPager!!) { tab, position ->
            tab.text = when (position) {
                0 -> "Exchange"
                1 -> "Transactions"
                else -> ""
            }
        }.attach()

        tabsViewPager?.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)

                if (position == 0) {
                    ProofPanelHelper.setScreenName("Exchange Dashboard")
                } else {
                    ProofPanelHelper.setScreenName("Transaction History")

                    // Refresh safely
                    val fragment = supportFragmentManager.fragments.find {
                        it is TransactionsFragment
                    }
                    (fragment as? TransactionsFragment)?.refreshTransactions()
                }
            }
        })

        fab?.setOnClickListener {
            showDialog()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        ProofPanelHelper.stop()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        this.menu = menu
        setMenu()
        return true
    }

    private fun setMenu() {
        menu?.clear()
        menuInflater.inflate(
            if (Authentication.getToken() == null) R.menu.menu_logged_out
            else R.menu.menu_logged_in,
            menu
        )
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.login -> startActivity(Intent(this, LoginActivity::class.java))

            R.id.register -> startActivity(Intent(this, RegistrationActivity::class.java))

            R.id.logout -> {
                Authentication.clearToken()
                setMenu()
                Snackbar.make(fab!!, "Logged out successfully.", Snackbar.LENGTH_SHORT).show()
            }
        }
        return true
    }

    private fun showDialog() {
        transactionDialog = LayoutInflater.from(this)
            .inflate(R.layout.dialog_transaction, null, false)

        MaterialAlertDialogBuilder(this)
            .setView(transactionDialog)
            .setTitle("Add Transaction")
            .setMessage("Enter transaction details")
            .setPositiveButton("Add") { dialog, _ ->
                val usdAmountStr = transactionDialog
                    ?.findViewById<TextInputLayout>(R.id.txtInptUsdAmount)
                    ?.editText?.text.toString()

                val lbpAmountStr = transactionDialog
                    ?.findViewById<TextInputLayout>(R.id.txtInptLbpAmount)
                    ?.editText?.text.toString()

                val usdAmount = usdAmountStr.toFloatOrNull()
                val lbpAmount = lbpAmountStr.toFloatOrNull()

                if (usdAmount == null || usdAmount <= 0f) {
                    Snackbar.make(fab!!, "USD amount must be a positive number.", Snackbar.LENGTH_LONG).show()
                    return@setPositiveButton
                }

                if (lbpAmount == null || lbpAmount <= 0f) {
                    Snackbar.make(fab!!, "LBP amount must be a positive number.", Snackbar.LENGTH_LONG).show()
                    return@setPositiveButton
                }

                val radioGroup = transactionDialog?.findViewById<RadioGroup>(R.id.rdGrpTransactionType)

                if (radioGroup?.checkedRadioButtonId == -1) {
                    Snackbar.make(fab!!, "Please select a transaction direction.", Snackbar.LENGTH_LONG).show()
                    return@setPositiveButton
                }

                val usdToLbp = radioGroup?.checkedRadioButtonId == R.id.rdBtnBuyUsd

                val transaction = Transaction()
                transaction.usdAmount = usdAmount
                transaction.lbpAmount = lbpAmount
                transaction.usdToLbp = usdToLbp

                addTransaction(transaction)
                dialog.dismiss()
            }
            .setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun addTransaction(transaction: Transaction) {
        val token = Authentication.getToken()

        if (token == null) {
            Snackbar.make(fab!!, "You must be logged in to add a transaction.", Snackbar.LENGTH_LONG).show()
            return
        }

        ExchangeService.exchangeApi().addTransaction(transaction, "Bearer $token")
            .enqueue(object : Callback<Any> {
                override fun onResponse(call: Call<Any>, response: Response<Any>) {
                    when (response.code()) {
                        200, 201 -> {
                            Snackbar.make(fab!!, "Transaction added successfully!", Snackbar.LENGTH_LONG).show()

                            val fragment = supportFragmentManager.findFragmentByTag("f1")
                            (fragment as? TransactionsFragment)?.refreshTransactions()
                        }

                        400 -> Snackbar.make(fab!!, "Invalid transaction data.", Snackbar.LENGTH_LONG).show()

                        401 -> {
                            Authentication.clearToken()
                            setMenu()
                            Snackbar.make(fab!!, "Session expired. Please log in again.", Snackbar.LENGTH_LONG).show()
                        }

                        403 -> Snackbar.make(fab!!, "Access forbidden.", Snackbar.LENGTH_LONG).show()

                        429 -> Snackbar.make(fab!!, "Too many requests. Wait and try again.", Snackbar.LENGTH_LONG).show()

                        else -> Snackbar.make(fab!!, "Error ${response.code()}. Please try again.", Snackbar.LENGTH_LONG).show()
                    }
                }

                override fun onFailure(call: Call<Any>, t: Throwable) {
                    Snackbar.make(fab!!, "Network error. Check your connection.", Snackbar.LENGTH_LONG).show()
                }
            })
    }
}