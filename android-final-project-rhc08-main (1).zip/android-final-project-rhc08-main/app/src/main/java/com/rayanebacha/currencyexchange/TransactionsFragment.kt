package com.rayanebacha.currencyexchange

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ListView
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.google.android.material.snackbar.Snackbar
import com.rayanebacha.currencyexchange.api.Authentication
import com.rayanebacha.currencyexchange.api.ExchangeService
import com.rayanebacha.currencyexchange.api.model.Transaction
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class TransactionsFragment : Fragment() {

    private var listview: ListView? = null
    private var transactions: ArrayList<Transaction> = ArrayList()
    private var adapter: TransactionAdapter? = null

    inner class TransactionAdapter(
        private val inflater: LayoutInflater,
        private val dataSource: List<Transaction>
    ) : BaseAdapter() {

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val view: View = inflater.inflate(R.layout.item_transaction, parent, false)
            val t = dataSource[position]

            view.findViewById<TextView>(R.id.txtTransactionType).text =
                if (t.usdToLbp == true) "Buy USD" else "Sell USD"

            view.findViewById<TextView>(R.id.txtTransactionAmounts).text =
                "${t.usdAmount} USD / ${t.lbpAmount} LBP"

            view.findViewById<TextView>(R.id.txtTransactionDate).text =
                t.addedDate ?: ""

            return view
        }

        override fun getItem(position: Int): Any = dataSource[position]
        override fun getItemId(position: Int): Long = dataSource[position].id?.toLong() ?: 0
        override fun getCount(): Int = dataSource.size
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view: View = inflater.inflate(R.layout.fragment_transactions, container, false)
        listview = view.findViewById(R.id.listview)
        adapter = TransactionAdapter(layoutInflater, transactions)
        listview?.adapter = adapter
        fetchTransactions()
        return view
    }

    private fun fetchTransactions() {
        val token = Authentication.getToken() ?: return

        ExchangeService.exchangeApi()
            .getTransactions("Bearer $token")
            .enqueue(object : Callback<List<Transaction>> {
                override fun onFailure(call: Call<List<Transaction>>, t: Throwable) {
                    view?.let {
                        Snackbar.make(it, "Network error. Check your connection.", Snackbar.LENGTH_LONG).show()
                    }
                }

                override fun onResponse(
                    call: Call<List<Transaction>>,
                    response: Response<List<Transaction>>
                ) {
                    when (response.code()) {
                        200 -> {
                            val body = response.body() ?: return
                            transactions.clear()
                            transactions.addAll(body)
                            adapter?.notifyDataSetChanged()
                        }
                        401 -> {
                            Authentication.clearToken()
                            view?.let {
                                Snackbar.make(it, "Session expired. Please log in again.", Snackbar.LENGTH_LONG).show()
                            }
                        }
                        403 -> view?.let {
                            Snackbar.make(it, "Access forbidden.", Snackbar.LENGTH_LONG).show()
                        }
                        429 -> view?.let {
                            Snackbar.make(it, "Too many requests. Wait and try again.", Snackbar.LENGTH_LONG).show()
                        }
                        else -> view?.let {
                            Snackbar.make(it, "Error ${response.code()}. Try again.", Snackbar.LENGTH_LONG).show()
                        }
                    }
                }
            })
    }

    fun refreshTransactions() {
        transactions.clear()
        adapter?.notifyDataSetChanged()
        fetchTransactions()
    }
}