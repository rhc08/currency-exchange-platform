package com.rayanebacha.currencyexchange

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputLayout
import com.rayanebacha.currencyexchange.api.Authentication
import com.rayanebacha.currencyexchange.api.ExchangeService
import com.rayanebacha.currencyexchange.api.model.Token
import com.rayanebacha.currencyexchange.api.model.User
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RegistrationActivity : AppCompatActivity() {

    private var usernameEditText: TextInputLayout? = null
    private var passwordEditText: TextInputLayout? = null
    private var submitButton: Button? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)

        ProofPanelHelper.start(window.decorView.rootView, "Register Screen")

        usernameEditText = findViewById(R.id.txtInptUsername)
        passwordEditText = findViewById(R.id.txtInptPassword)
        submitButton = findViewById(R.id.btnSubmit)

        submitButton?.setOnClickListener {
            createUser()
        }

        val backButton = findViewById<Button>(R.id.btnBack)

        backButton.setOnClickListener {
            finish()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        ProofPanelHelper.stop()
    }

    private fun createUser() {
        val user = User()
        user.username = usernameEditText?.editText?.text.toString()
        user.password = passwordEditText?.editText?.text.toString()

        ExchangeService.exchangeApi().addUser(user).enqueue(object : Callback<User> {
            override fun onFailure(call: Call<User>, t: Throwable) {
                Snackbar.make(submitButton as View, "Could not create account.", Snackbar.LENGTH_LONG).show()
            }

            override fun onResponse(call: Call<User>, response: Response<User>) {
                when (response.code()) {
                    201 -> {
                        ExchangeService.exchangeApi().authenticate(user).enqueue(object : Callback<Token> {
                            override fun onFailure(call: Call<Token>, t: Throwable) {
                                Snackbar.make(submitButton as View, "Account created but login failed.", Snackbar.LENGTH_LONG).show()
                            }

                            override fun onResponse(call: Call<Token>, response: Response<Token>) {
                                response.body()?.token?.let {
                                    Authentication.saveToken(it)
                                }
                                Snackbar.make(submitButton as View, "Account created!", Snackbar.LENGTH_LONG).show()
                                onCompleted()
                            }
                        })
                    }
                    409 -> Snackbar.make(submitButton as View, "Username already exists.", Snackbar.LENGTH_LONG).show()
                    400 -> Snackbar.make(submitButton as View, "Invalid data. Check your inputs.", Snackbar.LENGTH_LONG).show()
                    429 -> {
                        Snackbar.make(submitButton as View, "Too many requests. Wait and try again.", Snackbar.LENGTH_LONG).show()
                        submitButton?.isEnabled = false
                        submitButton?.postDelayed({ submitButton?.isEnabled = true }, 5000)
                    }
                    else -> Snackbar.make(submitButton as View, "Registration failed. Try again.", Snackbar.LENGTH_LONG).show()
                }
            }
        })
    }

    private fun onCompleted() {
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
        startActivity(intent)
    }
}