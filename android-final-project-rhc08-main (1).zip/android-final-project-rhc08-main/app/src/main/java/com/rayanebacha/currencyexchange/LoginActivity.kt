package com.rayanebacha.currencyexchange

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputLayout
import com.rayanebacha.currencyexchange.api.Authentication
import com.rayanebacha.currencyexchange.api.ExchangeService
import com.rayanebacha.currencyexchange.api.model.Token
import com.rayanebacha.currencyexchange.api.model.User
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LoginActivity : AppCompatActivity() {

    private var usernameEditText: TextInputLayout? = null
    private var passwordEditText: TextInputLayout? = null
    private var submitButton: Button? = null

    private var failedLoginAttempts = 0
    private val maxFailedAttempts = 5
    private val lockoutTimeMs = 30000L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        ProofPanelHelper.start(window.decorView.rootView, "Login Screen")

        usernameEditText = findViewById(R.id.txtInptUsername)
        passwordEditText = findViewById(R.id.txtInptPassword)
        submitButton = findViewById(R.id.btnSubmit)

        submitButton?.setOnClickListener {
            login()
        }

        val backButton = findViewById<Button>(R.id.btnBack)

        backButton.setOnClickListener {
            finish()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        ProofPanelHelper.stop()
    }

    private fun login() {
        val username = usernameEditText?.editText?.text.toString().trim()
        val password = passwordEditText?.editText?.text.toString().trim()

        usernameEditText?.error = null
        passwordEditText?.error = null

        if (username.isEmpty()) {
            usernameEditText?.error = "Username is required."
            return
        }

        if (password.isEmpty()) {
            passwordEditText?.error = "Password is required."
            return
        }

        val user = User()
        user.username = username
        user.password = password

        submitButton?.isEnabled = false

        ExchangeService.exchangeApi().authenticate(user).enqueue(object : Callback<Token> {
            override fun onFailure(call: Call<Token>, t: Throwable) {
                submitButton?.isEnabled = true
                showMessage("Could not connect to the backend. Please try again.")
            }

            override fun onResponse(call: Call<Token>, response: Response<Token>) {
                submitButton?.isEnabled = true

                when (response.code()) {
                    200 -> {
                        failedLoginAttempts = 0

                        val token = response.body()?.token

                        if (token != null) {
                            Authentication.saveToken(token)
                            showMessage("Logged in successfully.")
                            onCompleted()
                        } else {
                            passwordEditText?.error = "Login failed. Token was not received."
                            showMessage("Login failed. Token was not received.")
                        }
                    }

                    401, 403 -> {
                        failedLoginAttempts++

                        if (failedLoginAttempts >= maxFailedAttempts) {
                            passwordEditText?.error = "Too many failed attempts. Wait and try again."
                            showMessage("Too many requests. Wait and try again.")

                            submitButton?.isEnabled = false
                            submitButton?.postDelayed({
                                failedLoginAttempts = 0
                                submitButton?.isEnabled = true
                                passwordEditText?.error = null
                            }, lockoutTimeMs)
                        } else {
                            passwordEditText?.error = "Invalid username or password."
                            showMessage("Invalid username or password.")
                        }
                    }

                    429 -> {
                        passwordEditText?.error = "Too many requests. Wait and try again."
                        showMessage("Too many requests. Wait and try again.")

                        submitButton?.isEnabled = false
                        submitButton?.postDelayed({
                            submitButton?.isEnabled = true
                            passwordEditText?.error = null
                        }, lockoutTimeMs)
                    }

                    else -> {
                        passwordEditText?.error = "Login failed. Please try again."
                        showMessage("Login failed. Please try again.")
                    }
                }
            }
        })
    }

    private fun showMessage(message: String) {
        Snackbar.make(submitButton as View, message, Snackbar.LENGTH_LONG).show()
    }

    private fun onCompleted() {
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
        finish()
    }
}