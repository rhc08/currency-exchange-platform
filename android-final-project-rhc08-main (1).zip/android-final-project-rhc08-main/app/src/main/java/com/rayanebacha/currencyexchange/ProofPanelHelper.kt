package com.rayanebacha.currencyexchange

import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.*

object ProofPanelHelper {

    private val handler = Handler(Looper.getMainLooper())
    private var ticker: Runnable? = null
    private var currentRootView: View? = null

    fun start(rootView: View, screenName: String) {
        currentRootView = rootView
        setScreenName(screenName)

        ticker?.let { handler.removeCallbacks(it) }

        ticker = object : Runnable {
            override fun run() {
                val txtDateTime = currentRootView?.findViewById<TextView>(R.id.txtProofDateTime)
                val sdf = SimpleDateFormat("dd MMM yyyy  HH:mm:ss", Locale.getDefault())
                txtDateTime?.text = sdf.format(Date())
                handler.postDelayed(this, 1000)
            }
        }

        handler.post(ticker!!)
    }

    fun setScreenName(screenName: String) {
        val txtScreen = currentRootView?.findViewById<TextView>(R.id.txtProofScreen)
        txtScreen?.text = screenName
    }

    fun stop() {
        ticker?.let { handler.removeCallbacks(it) }
        ticker = null
        currentRootView = null
    }
}