package com.rayanebacha.currencyexchange

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputLayout
import com.rayanebacha.currencyexchange.api.ExchangeService
import com.rayanebacha.currencyexchange.api.model.ExchangeRates
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ExchangeFragment : Fragment() {

    private var buyUsdTextView: TextView? = null
    private var sellUsdTextView: TextView? = null
    private var progressBar: ProgressBar? = null
    private var btnRefresh: Button? = null
    private var usdToLbpRate: Float? = null
    private var lbpToUsdRate: Float? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view: View = inflater.inflate(R.layout.fragment_exchange, container, false)

        buyUsdTextView = view.findViewById(R.id.txtBuyUsdRate)
        sellUsdTextView = view.findViewById(R.id.txtSellUsdRate)
        progressBar = view.findViewById(R.id.progressBar)
        btnRefresh = view.findViewById(R.id.btnRefresh)

        val calcAmountInput = view.findViewById<TextInputLayout>(R.id.txtInptCalcAmount)
        val calcRadioGroup = view.findViewById<RadioGroup>(R.id.rdGrpCalc)
        val calcButton = view.findViewById<Button>(R.id.btnCalc)
        val calcResult = view.findViewById<TextView>(R.id.txtCalcResult)

        calcButton.setOnClickListener {
            val amount = calcAmountInput.editText?.text.toString().toFloatOrNull()
            if (amount == null) {
                calcResult.text = "Enter a valid amount"
                return@setOnClickListener
            }
            val usdToLbp = calcRadioGroup.checkedRadioButtonId == R.id.rdBtnUsdToLbp
            if (usdToLbp) {
                val rate = usdToLbpRate
                if (rate != null) calcResult.text = "≈ ${String.format("%.2f", amount * rate)} LBP"
                else calcResult.text = "Rate not available"
            } else {
                val rate = lbpToUsdRate
                if (rate != null && rate != 0f) calcResult.text = "≈ ${String.format("%.2f", amount / rate)} USD"
                else calcResult.text = "Rate not available"
            }
        }

        btnRefresh?.setOnClickListener {
            fetchRates()
        }

        fetchRates()
        return view
    }

    fun fetchRates() {
        progressBar?.visibility = View.VISIBLE
        btnRefresh?.isEnabled = false

        ExchangeService.exchangeApi().getExchangeRates().enqueue(object : Callback<ExchangeRates> {
            override fun onResponse(call: Call<ExchangeRates>, response: Response<ExchangeRates>) {
                progressBar?.visibility = View.GONE
                btnRefresh?.isEnabled = true

                when (response.code()) {
                    200 -> {
                        val responseBody = response.body()
                        usdToLbpRate = responseBody?.usdToLbp
                        lbpToUsdRate = responseBody?.lbpToUsd

                        buyUsdTextView?.text = usdToLbpRate?.let {
                            String.format("%.2f", it)
                        } ?: "N/A"

                        sellUsdTextView?.text = lbpToUsdRate?.let {
                            if (it != 0f) String.format("%.2f", 1f / it)
                            else "N/A"
                        } ?: "N/A"
                    }
                    429 -> {
                        view?.let { Snackbar.make(it, "Too many requests. Wait and try again.", Snackbar.LENGTH_LONG).show() }
                    }
                    else -> {
                        buyUsdTextView?.text = "N/A"
                        sellUsdTextView?.text = "N/A"
                        view?.let { Snackbar.make(it, "Failed to load rates. Try again.", Snackbar.LENGTH_LONG).show() }
                    }
                }
            }

            override fun onFailure(call: Call<ExchangeRates>, t: Throwable) {
                progressBar?.visibility = View.GONE
                btnRefresh?.isEnabled = true
                buyUsdTextView?.text = "N/A"
                sellUsdTextView?.text = "N/A"
                view?.let { Snackbar.make(it, "Network error. Check your connection.", Snackbar.LENGTH_LONG).show() }
            }
        })
    }
}